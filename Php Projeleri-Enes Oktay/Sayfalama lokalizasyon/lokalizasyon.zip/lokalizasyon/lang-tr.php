<?php
//TÜRKÇE DİL DOSYASI

$dl_anasayfa    = "Ana Sayfa";
$dl_hakkimizda  = "Hakkımızda";
$dl_iletisim    = "İletişim";

?>