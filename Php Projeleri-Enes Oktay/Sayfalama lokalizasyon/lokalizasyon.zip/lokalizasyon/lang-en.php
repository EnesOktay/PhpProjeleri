<?php
//İNGİLİZCE DİL DOSYASI

$dl_anasayfa    = "Main Page";
$dl_hakkimizda  = "About Us";
$dl_iletisim    = "Contact Us";

?>